# iOS-style launcher for Fire tablets

1. Open this folder in Android Studio (let it sync / create the Gradle wrapper).
2. Build > Build APK(s). Output: app/build/outputs/apk/debug/app-debug.apk
3. Sideload onto the Fire tablet (Settings > Security > Apps from Unknown Sources, then open the APK).
4. Press Home and choose "iOS Home" > Always.
   If Fire OS doesn't offer the choice, over ADB run:
   adb shell cmd package set-home-activity com.example.iosfire/.MainActivity

Features: rounded-square icons, paged home screen with dots, glass dock,
search pill, long-press menu (dock / app info / uninstall), your own wallpaper.
