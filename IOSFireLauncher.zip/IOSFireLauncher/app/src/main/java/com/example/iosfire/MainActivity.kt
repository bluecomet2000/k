package com.example.iosfire

import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Outline
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.*
import androidx.viewpager.widget.PagerAdapter
import androidx.viewpager.widget.ViewPager

class MainActivity : Activity() {

    class App(val label: String, val pkg: String, val intent: Intent, val icon: Drawable)

    private var apps = listOf<App>()
    private lateinit var pager: ViewPager
    private lateinit var dotsRow: LinearLayout
    private lateinit var dockRow: LinearLayout
    private lateinit var prefs: SharedPreferences
    private var cols = 0
    private var rows = 0
    private var searchDialog: Dialog? = null

    private val SOFT_WHITE = 0x66FFFFFF
    private val GLASS = 0x55FFFFFF

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            loadApps(); render(true)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("dock", MODE_PRIVATE)

        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        @Suppress("DEPRECATION")
        root.setOnApplyWindowInsetsListener { v, ins ->
            v.setPadding(
                ins.systemWindowInsetLeft, ins.systemWindowInsetTop,
                ins.systemWindowInsetRight, ins.systemWindowInsetBottom
            )
            ins
        }

        pager = ViewPager(this)
        root.addView(pager, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        pager.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> render(false) }
        pager.addOnPageChangeListener(object : ViewPager.SimpleOnPageChangeListener() {
            override fun onPageSelected(position: Int) = updateDots(position)
        })

        dotsRow = LinearLayout(this).apply { gravity = Gravity.CENTER }
        root.addView(dotsRow, LinearLayout.LayoutParams(MATCH_PARENT, dp(14)))

        val search = TextView(this).apply {
            text = "Search"
            setTextColor(Color.WHITE)
            textSize = 14f
            gravity = Gravity.CENTER
            background = rounded(GLASS, dp(16))
            setPadding(dp(36), dp(6), dp(36), dp(6))
            setOnClickListener { showSearch() }
        }
        root.addView(search, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            topMargin = dp(8); bottomMargin = dp(12)
        })

        dockRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            background = rounded(GLASS, dp(32))
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        root.addView(dockRow, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            bottomMargin = dp(12)
        })

        setContentView(root)

        loadApps()
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        registerReceiver(pkgReceiver, f)
    }

    override fun onDestroy() {
        unregisterReceiver(pkgReceiver)
        super.onDestroy()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        searchDialog?.dismiss()
        pager.currentItem = 0
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { /* a launcher has nowhere to go back to */ }

    // ---------- data ----------

    private fun loadApps() {
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        apps = pm.queryIntentActivities(q, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map {
                val ai = it.activityInfo
                val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                    .setClassName(ai.packageName, ai.name)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                App(it.loadLabel(pm).toString(), ai.packageName, i, it.loadIcon(pm))
            }
            .sortedBy { it.label.lowercase() }
    }

    private fun dockPackages(): List<String> {
        val installed = apps.map { it.pkg }.toSet()
        val saved = prefs.getString("pkgs", null)
        if (saved != null) return saved.split(",").filter { it in installed }
        val defaults = listOf("com.amazon.cloud9", "com.amazon.venezia", "com.android.settings", "com.amazon.photos")
        return defaults.filter { it in installed }.ifEmpty { apps.take(4).map { it.pkg } }
    }

    private fun saveDock(list: List<String>) {
        prefs.edit().putString("pkgs", list.joinToString(",")).apply()
        render(true)
    }

    // ---------- rendering ----------

    private fun render(force: Boolean) {
        val w = pager.width
        val h = pager.height
        if (w == 0 || h == 0) return
        val c = maxOf(4, w / dp(130))
        val r = maxOf(3, h / dp(140))
        if (!force && c == cols && r == rows) return
        cols = c; rows = r

        val dock = dockPackages()
        val grid = apps.filter { it.pkg !in dock }
        val perPage = cols * rows
        val chunks = grid.chunked(perPage).ifEmpty { listOf(emptyList()) }
        val current = pager.currentItem

        val pages = chunks.map { page ->
            LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(24), dp(24), dp(24), dp(8))
                for (row in 0 until rows) {
                    val line = LinearLayout(context)
                    line.layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f)
                    for (col in 0 until cols) {
                        val a = page.getOrNull(row * cols + col)
                        line.addView(if (a != null) cell(a) else View(context).apply {
                            layoutParams = LinearLayout.LayoutParams(0, MATCH_PARENT, 1f)
                        })
                    }
                    addView(line)
                }
            }
        }
        pager.adapter = Pages(pages)
        pager.currentItem = current.coerceAtMost(pages.size - 1)

        dotsRow.removeAllViews()
        if (pages.size > 1) repeat(pages.size) {
            dotsRow.addView(View(this), LinearLayout.LayoutParams(dp(7), dp(7)).apply {
                marginStart = dp(5); marginEnd = dp(5)
            })
        }
        updateDots(pager.currentItem)

        dockRow.removeAllViews()
        dockRow.visibility = if (dock.isEmpty()) View.GONE else View.VISIBLE
        for (p in dock.take(6)) {
            val a = apps.first { it.pkg == p }
            val icon = iconView(a, dp(68))
            icon.setOnClickListener { launch(a) }
            icon.setOnLongClickListener { showMenu(a); true }
            dockRow.addView(icon, LinearLayout.LayoutParams(dp(68), dp(68)).apply {
                marginStart = dp(8); marginEnd = dp(8)
            })
        }
    }

    private fun updateDots(sel: Int) {
        for (i in 0 until dotsRow.childCount) {
            dotsRow.getChildAt(i).background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(if (i == sel) Color.WHITE else SOFT_WHITE)
            }
        }
    }

    private fun cell(a: App): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        layoutParams = LinearLayout.LayoutParams(0, MATCH_PARENT, 1f)
        addView(iconView(a, dp(68)), LinearLayout.LayoutParams(dp(68), dp(68)))
        addView(TextView(context).apply {
            text = a.label
            setTextColor(Color.WHITE)
            textSize = 12f
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            gravity = Gravity.CENTER
            setShadowLayer(4f, 0f, 1f, 0x99000000.toInt())
        }, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply {
            topMargin = dp(6); marginStart = dp(4); marginEnd = dp(4)
        })
        setOnClickListener { launch(a) }
        setOnLongClickListener { showMenu(a); true }
    }

    /** iOS-style rounded-square ("squircle-ish") icon. */
    private fun iconView(a: App, size: Int): FrameLayout {
        val frame = FrameLayout(this)
        frame.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) {
                o.setRoundRect(0, 0, v.width, v.height, size * 0.2237f)
            }
        }
        frame.clipToOutline = true
        val img = ImageView(this)
        img.setImageDrawable(a.icon)
        val adaptive = Build.VERSION.SDK_INT >= 26 && a.icon is AdaptiveIconDrawable
        if (adaptive) {
            img.scaleType = ImageView.ScaleType.FIT_XY
            img.scaleX = 1.4f; img.scaleY = 1.4f
        } else {
            frame.setBackgroundColor(Color.WHITE)
            val pad = (size * 0.14f).toInt()
            img.setPadding(pad, pad, pad, pad)
        }
        frame.addView(img, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        return frame
    }

    // ---------- actions ----------

    private fun launch(a: App) {
        try { startActivity(a.intent) } catch (e: Exception) {
            Toast.makeText(this, "Can't open ${a.label}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showMenu(a: App) {
        val dock = dockPackages().toMutableList()
        val inDock = a.pkg in dock
        val items = arrayOf(if (inDock) "Remove from Dock" else "Add to Dock", "App Info", "Uninstall App")
        AlertDialog.Builder(this).setTitle(a.label).setItems(items) { _, which ->
            when (which) {
                0 -> {
                    if (inDock) dock.remove(a.pkg) else if (dock.size < 6) dock.add(a.pkg)
                    else Toast.makeText(this, "Dock is full", Toast.LENGTH_SHORT).show()
                    saveDock(dock)
                }
                1 -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.pkg}")))
                2 -> startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${a.pkg}")))
            }
        }.show()
    }

    private fun showSearch() {
        val d = Dialog(this, android.R.style.Theme_Material_NoActionBar)
        d.window?.setBackgroundDrawable(ColorDrawable(0xD9000000.toInt()))
        d.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        val col = LinearLayout(d.context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(40), dp(64), dp(40), dp(16))
        }
        val input = EditText(d.context).apply {
            hint = "Search"
            setHintTextColor(SOFT_WHITE)
            setTextColor(Color.WHITE)
            textSize = 20f
            isSingleLine = true
            background = rounded(0x33FFFFFF, dp(14))
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        val list = ListView(d.context)
        var shown = apps
        val adapter = ArrayAdapter(d.context, android.R.layout.simple_list_item_1, shown.map { it.label }.toMutableList())
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ -> d.dismiss(); launch(shown[pos]) }
        input.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                val q = s.toString().trim()
                shown = apps.filter { it.label.contains(q, ignoreCase = true) }
                adapter.clear(); adapter.addAll(shown.map { it.label })
            }
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })
        col.addView(input, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        col.addView(list, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f).apply { topMargin = dp(12) })
        d.setContentView(col)
        searchDialog = d
        d.show()
    }

    // ---------- helpers ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = radius.toFloat()
    }

    inner class Pages(private val pages: List<View>) : PagerAdapter() {
        override fun getCount() = pages.size
        override fun isViewFromObject(v: View, o: Any) = v === o
        override fun instantiateItem(c: ViewGroup, p: Int): Any { c.addView(pages[p]); return pages[p] }
        override fun destroyItem(c: ViewGroup, p: Int, o: Any) { c.removeView(o as View) }
    }
}
